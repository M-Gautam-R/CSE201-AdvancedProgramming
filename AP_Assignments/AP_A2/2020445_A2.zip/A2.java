import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import javax.swing.text.StyledEditorKit.BoldAction;

class Instructor implements Viewing,Adding
{
    private String name;
    private CourseInstructor courseInstructor;
    private static Course course;
    private CommentSection commentSection;
    private static int i =0;
    Instructor(Course co,CommentSection coms)
    {
        course=co;
        commentSection=coms;
        name= "I"+i;
        i++;
    }
    public void See_Comments()
    {
        for (String s : commentSection.getComments()) 
        {
           System.out.println(s); 
        }  
    }
    public void See_Assessment()
    {
        for (assignment assignments : course.getAssignments()) 
        {
           System.out.println(assignments.toString());
        }
        for (quiz quizzes : course.getQuizzes()) 
        {
           System.out.println(quizzes.toString());
        }
    }
    public void See_Submission()
    {
        
    }
    public void See_LectureMats()
    {
        for (LectureSlide sLectureSlide : course.getLectureSlides()) 
        {
            sLectureSlide.ToString();    
        }
        for (LectureVideo vLectureVideo : course.getLectureVideos()) 
        {
            vLectureVideo.ToString();    
        }
    }

    public CourseInstructor gCourseInstructor()
    {
        return courseInstructor;
    }
    public void Add_Comments(String s)
    {
        s=s +" "+ name+" "+ new Date();
        commentSection.Add_Comment(s);
    }
    public void Grade()
    {

    }
 
    public void Add_Assignment(assignment assignment)
    {
        course.getAssignments().add(assignment);
    }

    public void Add_Quiz(quiz quiz)
    {
        course.getQuizzes().add(quiz);
    }
    public void AddSlide(LectureSlide slide)
    {
        System.out.println(course.getLectureSlides());
        course.getLectureSlides().add(slide);
    }
    public void Addvideo(LectureVideo video)
    {
        course.getLectureVideos().add(video);
    }


}

class Student implements Viewing, Adding
{
    private Course course;
    private ArrayList<assignment> assignment_left;
    private ArrayList<quiz> quizzes_left;
    private ArrayList<String> submiStrings;
    private CommentSection commentSection;
    Student(Course C)
    {
        course=C;
        assignment_left=course.getAssignments();
        quizzes_left=course.getQuizzes();
    }
    public void See_Comments()
    {
        for (String s : commentSection.getComments()) 
        {
           System.out.println(s); 
        }  
    }
    public void See_Assessment()
    {
        assignment_left=course.getAssignments();
        for (assignment assignments : course.getAssignments()) 
        {
           System.out.println(assignments.toString());
        }
        quizzes_left = course.getQuizzes();
        for (quiz quizzes : course.getQuizzes()) 
        {
           System.out.println(quizzes.toString());
        }
    }
    public void Add_Submission()
    {
        Scanner sc =new Scanner(System.in);
        assignment_left=course.getAssignments();
        int flag =0;
        for (int i = 0; i < assignment_left.size(); i++) 
        {
            if(assignment_left.get(i).getSubString()==null && assignment_left.get(i).getCLose()==false)
            {
                System.out.println(i+" "+assignment_left.get(i).toString());
                flag=1;
            }
                
        }
        int k = assignment_left.size();
        quizzes_left = course.getQuizzes();
        for (int i = 0; i < quizzes_left.size(); i++) 
        {
            int m = k+i;
            
            if((quizzes_left.get(i).getSubString()==null) && (quizzes_left.get(i).getCLose()==false))
            {
                System.out.println(m+" "+quizzes_left.get(i).toString());
                flag=1; 
            }
           
        }
        if(flag==1)
        {
            System.out.println("Enter Id of assessment");
            int choice = sc.nextInt();
            if(choice<assignment_left.size())
            {
                System.out.println(choice+" "+assignment_left.get(choice).toString());    
                String sub = sc.next();
                if(sub.endsWith(".zip"))
                {
                    assignment_left.get(choice).SetSubmit(sub);
                    //submiStrings.add(sub);
                }
                else
                {
                    System.out.println("Invalid file format");
                }
            }
            else if (choice>=assignment_left.size())
            {
                int m = choice-k;
                System.out.println(m+" "+quizzes_left.get(m).toString());
                String sub = sc.next();
                quizzes_left.get(m).SetSubmit(sub);
                submiStrings.add(sub);
            }
        }
        else
        {
            System.out.println("no assessments");
        }
        
        //sc.close();
    }

    public void See_LectureMats()
    {
        for (LectureSlide sLectureSlide : course.getLectureSlides()) 
        {
            sLectureSlide.ToString();    
        }
        for (LectureVideo vLectureVideo : course.getLectureVideos()) 
        {
            vLectureVideo.ToString();    
        }
    }
    public void Add_Comments(String s)
    {
        commentSection.Add_Comment(s);
    }
    public Course Getdetails()
    {
        return course;
    }

    public void See_Grades()
    {
        System.out.println("Ungraded submissions");
        for (assignment assignments : course.getAssignments()) 
        {
           if(assignments.getGrader()==null)
           {
               System.out.println("Submission:"+assignments.getSubString());
           }
        }
        for (quiz quizzes : course.getQuizzes()) 
        {
           if(quizzes.getGrader()==null)
           {
               System.out.println("Submission:"+quizzes.getSubString());
           }
        }
        System.out.println("Graded submissions");
        for (assignment assignments : course.getAssignments()) 
        {
           if(assignments.getGrader()!=null)
           {
               System.out.println("Submission:"+assignments.getSubString());
               System.out.println("marks scored:" +assignments.getMarks());
               System.out.println("graded by:" + assignments.getGrader());
           }
        }
        for (quiz quiz : course.getQuizzes()) 
        {
           if(quiz.getGrader()!=null)
           {
               System.out.println("Submission:"+quiz.getSubString());
               System.out.println("marks scored:" +quiz.getMarks());
               System.out.println("graded by:" + quiz.getGrader());
           }
        }
    }

}

class Course
{
    private static ArrayList<LectureSlide> lectureSlides =new ArrayList<>();
    private static ArrayList<LectureVideo> lectureVideos=new ArrayList<>();
    private static ArrayList<assignment> assignments=new ArrayList<>();
    private static ArrayList<quiz> quizzes=new ArrayList<>();

    public ArrayList<LectureSlide> getLectureSlides()
    {
        return lectureSlides;
    }
    
    public ArrayList<LectureVideo> getLectureVideos()
    {
        return lectureVideos;
    }
    public ArrayList<assignment> getAssignments()
    {
        return assignments;
    }
    public ArrayList<quiz> getQuizzes()
    {
        return quizzes;
    }
    public void Add_Assignment(assignment assignment)
    {
        assignments.add(assignment);
    }

    public void Add_Quiz(quiz quiz)
    {
        quizzes.add(quiz);
    }
    public void AddSlide(LectureSlide slide)
    {
        lectureSlides.add(slide);
    }
    public void Addvideo(LectureVideo video)
    {
        lectureVideos.add(video);
    }
}

class LectureSlide
{
    private String topic;
    private int No_Slides;
    private ArrayList<String> slides;
    private Date uploadDate;
    private Instructor Uploader;

    LectureSlide(String Topic, int slideno,ArrayList<String> slideList,Instructor instructor)
    {
        topic=Topic;
        No_Slides=slideno;
        slides=slideList;
        uploadDate=new Date();
        Uploader=instructor;
    }
    public void ToString()
    {
        System.out.println("Topic:" + topic + "No of slides:"+No_Slides+"\n");
        for (String s : slides) 
        {
            System.out.println("Content:" +s);    
        }
        System.out.println("Upload date:" +uploadDate +"by "+Uploader+"\n");
    }
}
class LectureVideo
{
    private String topic;
    private String videoFile;
    private Date uploadDate;
    private Instructor Uploader;

    
    LectureVideo(String Topic, String file,Instructor instructor)
    {
        topic=Topic;
        videoFile=file;
        uploadDate=new Date();
        Uploader=instructor;
    }
    
    public void ToString()
    {
        System.out.println("Topic:" + topic + "Video File"+videoFile+"\n");
        System.out.println("Upload date:" +uploadDate +"by "+Uploader+"\n");
    }
}

class assignment
{
    private int grade;
    private String question;
    private String submission;
    private boolean close;
    private Instructor grader;
    assignment(int marks, String questions)
    {
        grade=marks;
        question=questions;
        close=false;
    }

    public String toString()
    {
        return "Assignment : " +question +" , marks =" +grade +"\n";
    }
    
    public void SetSubmit(String s)
    {
        submission=s;
    }
    public String getSubString()
    {
        return submission;
    }
    public Instructor getGrader()
    {
        return grader;
    }

    public int getMarks()
    {
        return grade;
    }
    public void Setclose()
    {
        close=true;
    }

    public boolean getCLose()
    {
        return close;
    }
}

class quiz
{
    private static int grade=1;
    private String question;
    private String submission;
    private Instructor grader;
    private boolean close;
    quiz(String q)
    {
        question=q;
    }
    public String toString()
    {
        return "Quiz : " +question +" , marks =" +grade+"\n";
    }
    public void SetSubmit(String s)
    {
        submission=s;
    }
    
    public String getSubString()
    {
        return submission;
    }
    public Instructor getGrader()
    {
        return grader;
    }
    public int getMarks()
    {
        return grade;
    }
    public void Setclose()
    {
        close=true;
    }
    
    public boolean getCLose()
    {
        return close;
    }
}

class CourseInstructor
{
    private Course course;

    public void Add_Assignment(assignment assignment)
    {
        course.getAssignments().add(assignment);
    }

    public void Add_Quiz(quiz quiz)
    {
        course.getQuizzes().add(quiz);
    }
    public void AddSlide(LectureSlide slide)
    {
        System.out.println(course.getLectureSlides());
        course.getLectureSlides().add(slide);
    }
    public void Addvideo(LectureVideo video)
    {
        course.getLectureVideos().add(video);
    }
}
class Menus
{
    private String LogOut= "Welcome to Backpack\n" + "1. Enter as instructor\n" + "2. Enter as student\n" + "3. Exit";
    private String instructorMenu = "INSTRUCTOR MENU\n" +"1. Add class material\n" +"2. Add assessments\n" + "3. View lecture materials\n"+"4. View assessments\n"+"5. Grade assessments\n"+"6. Close assessment\n"+"7. View comments\n"+"8. Add comments\n"+"9. Logout\n";
    private String StudentMenu = "STUDENT MENU\n" +"1. View lecture materials\n" +"2. View assessments\n" + "3. Submit assessment\n"+"4. View grades\n"+"5. View comments\n"+"6. Add comments\n"+"7. Logout\n";

    public String GetLogOut()
    {
        return LogOut;
    }
    public String getInstructorString()
    {
        return instructorMenu;
    }
    public String getStudentString()
    {
        return StudentMenu;
    }
}
interface Viewing // for viewing assignments, comments and submissions and grades
{
    public void See_Comments();
    public void See_Assessment();
    public void See_LectureMats();  
}

interface Adding //for adding comments and assignments and submissions grades
{
    public void Add_Comments(String s);
}

class CommentSection 
{
    private static ArrayList<String> comments= new ArrayList<>();
    public ArrayList<String> getComments()
    {
        return comments;
    }
    public void Add_Comment(String s)
    {
        comments.add(s);
    }
}
public class A2 
{
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        Course Dummy = new Course(); 
        Student student1 =new Student(Dummy);
        Student student2=new Student(Dummy);
        Student student3=new Student(Dummy);

        ArrayList<Student> students =new ArrayList<>();
        ArrayList<Instructor> instructors =new ArrayList<>();
        students.add(student1);
        students.add(student2);
        students.add(student3);
        CommentSection commentSection= new CommentSection();
       
        Instructor I0 = new Instructor(Dummy,commentSection);
        Instructor I1 = new Instructor(Dummy,commentSection);
        instructors.add(I0);
        instructors.add(I1);
        Menus menu = new Menus();
        
        
        CourseInstructor inst = new CourseInstructor();
        //DummyCourse.AddInstructor(I0);
        System.out.println(instructors.get(0));
        int logcheck=0;         //1 is for instructor 2 is for student 3 is for exit
        int loginChoice;
        int IUserchoice=0;      
        int SUserchoice=0;               
        while(true)
        {
            if(logcheck==0)
            {
                System.out.println(menu.GetLogOut()) ;
                loginChoice=scan.nextInt();
                if(loginChoice==1)
                {
                    int i=0;
                    for (Instructor instructor : instructors) 
                    {
                        System.out.println(i+ " "+instructor);
                        i++;    
                    }
                    System.out.println("Enter instructor choice");
                    IUserchoice=scan.nextInt();
                    logcheck=1;
                }
                else if(loginChoice==2)
                {
                    int i=0;
                    for (Student student : students) 
                    {
                        System.out.println(i+ " "+student);
                        i++;    
                    }
                    System.out.println("Enter student choice");
                    SUserchoice=scan.nextInt();
                    logcheck=2;
                    
                }
                else if (loginChoice==3)
                {
                    logcheck=3;
                }
            }                
            
            else if (logcheck==1)
            {
                System.out.println(menu.getInstructorString());
                System.out.println("enter choice");
                int Ichoice=scan.nextInt();
                if(Ichoice==1)
                {
                    System.out.println("1.Add lecture slide");
                    System.out.println("2.Add lecture video");
                    int choice=scan.nextInt();
                    if(choice==1)
                    {
                        System.out.println("Enter topic:");
                        String topic= scan.next();
                        System.out.println("enter no of slides:");
                        int num = scan.nextInt();
                        ArrayList<String> slide= new ArrayList<>();
                        for (int i = 0; i <num; i++) 
                        {   
                            System.out.println("Content of slide "+i);
                            slide.add(scan.next());
                        }
                        LectureSlide newslide = new LectureSlide(topic,num,slide,instructors.get(IUserchoice));
                        Dummy.AddSlide(newslide);
                    }
                    else if (choice==2)
                    {
                        System.out.println("Enter topic:");
                        String topic= scan.next();
                        System.out.println("enter filename of video:");
                        String file = scan.next();
                        if(file.endsWith(".mp4"))
                        {
                            LectureVideo newvideo = new LectureVideo(topic, file, instructors.get(IUserchoice));
                            Dummy.Addvideo(newvideo);
                        }
                        else
                        {
                            System.out.println("Invalid file format");
                        }
                    }
                }
                else if (Ichoice==2)
                {
                    System.out.println("1.Add Assignment");
                    System.out.println("2.Add Quiz");
                    int choice =scan.nextInt();
                    if(choice==1)
                    {
                        System.out.println("enter problem:");
                        String problem = scan.next();
                        System.out.println("enter max marks");
                        int num = scan.nextInt();
                        assignment newAss = new assignment(num, problem);
                        Dummy.Add_Assignment(newAss);
                    }
                    else if(choice==2)
                    {
                        System.out.println("enter problem:");
                        String problem = scan.next();
                        quiz newquiz = new quiz(problem);
                        Dummy.Add_Quiz(newquiz);
                    }
                }
                else if (Ichoice==3)
                {
                    instructors.get(IUserchoice).See_LectureMats();
                }  
                else if (Ichoice==4)
                {
                    instructors.get(IUserchoice).See_Assessment();
                }
                else if (Ichoice==5)
                {
                    
                }
                else if (Ichoice==6)
                {
                    System.out.println("open assignments");
                    for (int i = 0; i < Dummy.getAssignments().size(); i++) 
                    {
                        System.out.println(i+" "+Dummy.getAssignments().get(i).toString());       
                    }
                    int k = Dummy.getAssignments().size();
                    for (int i = 0; i < Dummy.getQuizzes().size(); i++) 
                    {
                        int m = k+i;
                        System.out.println(m+" "+Dummy.getQuizzes().get(i).toString()); 
                    }
                    System.out.println("enter assignment to close");
                    int choice = scan.nextInt();
                    if(choice<Dummy.getAssignments().size())
                    {
                        Dummy.getAssignments().get(choice).Setclose();
                    }
                    else if (choice>=Dummy.getAssignments().size())
                    {
                        int m = choice-k;
                        Dummy.getQuizzes().get(m).Setclose();
                    }

                }
                else if (Ichoice==7)
                {
                    instructors.get(IUserchoice).See_Comments();
                }
                else if (Ichoice==8)
                {
                    System.out.println("Enter Comment:");
                    String s = scan.next();
                    instructors.get(IUserchoice).Add_Comments(s);
                }
                else if (Ichoice==9)
                {
                    logcheck=0;
                }
            }
            else if (logcheck==2)
            {
                System.out.println(menu.getStudentString());
                System.out.println("enter choice");
                int Schoice=scan.nextInt();

                if(Schoice==1)
                {
                    students.get(SUserchoice).See_LectureMats();
                }
                
                else if(Schoice==2)
                {
                    students.get(SUserchoice).See_Assessment();
                }
                
                else if(Schoice==3)
                {
                    students.get(SUserchoice).Add_Submission();
                }
                
                else if(Schoice==4)
                {
                    students.get(SUserchoice).See_Grades();
                }
                
                else if(Schoice==5)
                {
                    students.get(SUserchoice).See_Comments();
                }
                
                else if(Schoice==6)
                {
                    System.out.println("Enter comment:");
                    String s = scan.next();
                    students.get(SUserchoice).Add_Comments(s);

                }
                else if(Schoice==7)
                {
                    logcheck=0;
                }
            }
            else if(logcheck==3)
            {
                break;
            }   
        }        
    }    
}
