import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.io.*;
import java.util.*;
import java.lang.*;
class Game
{
    private ArrayList<Integer> numbers;
    private ArrayList<String> strings;
    public ArrayList<Integer> Generatenumber()
    {
        ArrayList<Integer> numbers = new ArrayList<>();
        while(true)
        {
            numbers.add(ThreadLocalRandom.current().nextInt(Integer.MIN_VALUE, Integer.MAX_VALUE ));
            numbers.add(ThreadLocalRandom.current().nextInt(Integer.MIN_VALUE, Integer.MAX_VALUE ));
            try 
            {
                int a = numbers.get(0)/numbers.get(1);
                break;   
            } 
            catch (ArithmeticException e) 
            {
                
            }
        }
        return numbers;
    }
    public int Generatetilenumber()
    {
        return ThreadLocalRandom.current().nextInt(0, 25 + 1);  // change it to more random numbers to implement muddy pool
    }

    public ArrayList<String> GenerateString()
    {
        ArrayList<String> strings = new ArrayList<>();
        String set = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder s1 = new StringBuilder();
        StringBuilder s2= new StringBuilder();
        for (int i = 0; i < 4; i++) 
        {
            s1.append(set.charAt(ThreadLocalRandom.current().nextInt(0, 51 + 1)));
        }
        for (int i = 0; i < 4; i++) 
        {
            s2.append(set.charAt(ThreadLocalRandom.current().nextInt(0, 51 + 1)));
        }
        strings.add(s1.toString());
        strings.add(s2.toString());
        return strings;
    }    
    public void AskQ()
    {
        System.out.println("Q&A round. String or Integer?");
        Scanner sc = new Scanner(System.in);
        String Input= sc.nextLine(); 

        if(Input.equals("String"))
        {
            ArrayList<String> strings = GenerateString();
            System.out.println("Give the result of concatenating "+strings.get(0)+" "+strings.get(1));
        }
        else if(Input.equals("Integer"))
        {
            ArrayList<Integer> numbers = Generatenumber();
            System.out.println("Give the result of dividing "+numbers.get(0)+" by "+numbers.get(1));            
        }
        sc.close();
    }
}
class Player
{
    private Bucket bucket;
    private Tile currentTile;
    private int Hops;
    public Player(int hops)
    {
        bucket= new Bucket();
        Hops=hops;
    }

    private void SetTile(Tile tile)
    {
        currentTile=tile;
    }
    public void SetHops()
    {
        Hops--;
    }
    public Tile GetTile()
    {
        return currentTile;
    }
    public int GetHops()
    {
        return Hops;
    }
    public void Hop(Tile next)
    {
        SetTile(next);
        SetHops();
    }
    public Bucket getBucket()
    {
        return bucket;
    }
}

class Tile 
{
    private int position;
    private Toy ToyStored;
    public Tile(int pos,Toy t)
    {
        position=pos;
        ToyStored=t;
    }

    public int GetPos()
    {
        return position;
    }
    public Toy GetToy()
    {
        return ToyStored;
    }
    // @Override
    // public Toy clone() 
    // {
    //     try
    //     {
    //         Tile cloned = (Tile)super.clone();     
    //         return cloned.GetToy();
    //     }
    //     catch(CloneNotSupportedException e)
    //     {
    //         System.out.println("Clone not created");
    //     }
    //     //Tile cloned = (Tile)super.clone();
    //     return null;
    // }
    // public Toy WinToy()
    // {
    //     return ToyStored.clone();
    // }
}

class Bucket
{
    private ArrayList<Toy> collectedToys;
    public Bucket()
    {
        collectedToys= new ArrayList<>();
    }
    public void AddToy(Toy t)
    {
        collectedToys.add(t);
    }
    public ArrayList<Toy> GetToys()
    {
        return collectedToys; 
    }
}
class calculator<T>
{
    private T val1;
    private T val2;
    public calculator(T t1, T t2)
    {
        val1=t1;
        val2=t2;
    }
    public boolean FindCorrectResult(T ans)
    {
        if(val1 instanceof Integer)
        {
            return (int)val1/(int)val2==(int) ans;
        }
        if (val1 instanceof String)
        {
            return ((String)val1+(String)val2).equals((String)ans);
        }
        return false;
    }
}
class Toy implements Cloneable
{
    private String name;
    public Toy(String n)
    {
        name=n;
    }
    public void Setname()
    {

    }
    public String Getname()
    {
        return name;
    }
    
    public Toy clone() 
    {
        try
        {
            Toy cloned = (Toy)super.clone();     
            return cloned;
        }
        catch(CloneNotSupportedException e)
        {
            System.out.println("Clone not created");
            return null;
        }
        //Tile cloned = (Tile)super.clone();
        
    }
}
class IncorrectInputException extends Exception 
{
    public IncorrectInputException(String message) 
    {
        super(message);
    }
}
public class A4next
{
    public static void main(String[] args) throws IncorrectInputException
    {
        Player p1 = new Player(5);
        Game g1 = new Game();
        ArrayList<Toy> toys = new ArrayList<>();
        ArrayList<Tile> carpet = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        Toy toy_1 = new Toy("MickeyMouse");
        Toy toy_2 = new Toy("DonaldDuck");
        Toy toy_3 = new Toy("GoofyToy");
        Toy toy_4 = new Toy("SimpleToy");
        Toy toy_5 = new Toy("BigToy");
        Toy toy_6 = new Toy("SmallToy");
        Toy toy_7 = new Toy("TeddyBear");
        Toy toy_8 = new Toy("Action Figure");
        Toy toy_9 = new Toy("Doll");
        Toy toy_10 = new Toy("SoftToy");
        Toy toy_11 = new Toy("GoofyToy");
        Toy toy_12 = new Toy("ComplexToy");
        Toy toy_13 = new Toy("XBOX");
        Toy toy_14 = new Toy("PS5");
        Toy toy_15 = new Toy("NIntendoSwitch");
        Toy toy_16 = new Toy("Sword");
        Toy toy_17 = new Toy("Gun");
        Toy toy_18= new Toy("Ball");
        Toy toy_19 = new Toy("ChickenLegs");
        Toy toy_20 = new Toy("PC");

        toys.add(new Toy("MickeyMouse"));
        toys.add(new Toy("DonaldDuck"));
        toys.add(new Toy("GoofyToy"));
        toys.add(toy_4);
        toys.add(toy_5);
        toys.add(toy_6);
        toys.add(toy_7);
        toys.add(toy_8);
        toys.add(toy_9);
        toys.add(toy_10);
        toys.add(toy_11);
        toys.add(toy_12);
        toys.add(toy_13);
        toys.add(toy_14);
        toys.add(toy_15);
        toys.add(toy_16);
        toys.add(toy_17);
        toys.add(toy_18);
        toys.add(toy_19);
        toys.add(toy_20);

        int k=1;
        for (int i = 1; i < 21; i++) 
        {
            carpet.add(new Tile(i, toys.get(i-1)));
        } 
        while(p1.GetHops()>0)
        {
            
            while(true)
            {
                try 
                {
                    System.out.println("Hit Enter for  Hop "+k);
                    
                    String start;
                    start=sc.nextLine();
                    if(start.equals("")==false)
                    {
                        throw new IncorrectInputException("Please press only enter");
                    }
                    else
                    {
                        k++;
                        break;
                    }
                }
                catch(IncorrectInputException e)
                {
                    System.out.println(e.getMessage());
                }

                finally
                {

                }                     
            }
            try 
            {
                p1.Hop(carpet.get(g1.Generatetilenumber()));
                System.out.println("Current tile is "+ p1.GetTile().GetPos());    
            } 
            catch (IndexOutOfBoundsException e) 

            {
                System.out.println("You landed in the muddy pool");
                p1.SetHops();
                continue;
            }
            String Input;
            if(p1.GetTile().GetPos()%2==0)
            {
                p1.getBucket().AddToy(p1.GetTile().GetToy().clone());
                System.out.println("You won a " +p1.getBucket().GetToys().get(p1.getBucket().GetToys().size()-1).Getname());
            }
            else if (p1.GetTile().GetPos()%2!=0)
            {
                //System.out.println("Q&A round. String or Integer?");
                while(true)
                {
                    try 
                    {
                        System.out.println("Q&A round. String or Integer?");
                        Input= sc.nextLine();
                        if(Input.equals("String")==false && Input.equals("Integer")==false)
                        {
                            throw new IncorrectInputException("Please enter either String or Integer");
                        }
                        else
                        {
                            break;
                        }
                    }
                    catch(IncorrectInputException e)
                    {
                        System.out.println(e.getMessage());
                    }

                    finally
                    {
    
                    }                     
                }
                if(Input.equals("String"))
                {
                    ArrayList<String> strings = g1.GenerateString();
                    calculator<String> calc = new calculator<String>(strings.get(0),strings.get(1));
                    System.out.println("Give the result of concatenating "+strings.get(0)+" "+strings.get(1));
                    String ans = sc.nextLine();
                    if(calc.FindCorrectResult(ans))
                    {
                        p1.getBucket().AddToy(p1.GetTile().GetToy().clone());
                        System.out.println("You won a " +p1.getBucket().GetToys().get(p1.getBucket().GetToys().size()-1).Getname());
                    }
                    else
                    {
                        System.out.println("Wrong answer, No Toy");
                    }
                }
                else if(Input.equals("Integer"))
                {
                    ArrayList<Integer> numbers = g1.Generatenumber();
                    calculator<Integer> calc = new calculator<Integer>(numbers.get(0),numbers.get(1));
                    System.out.println("Give the result of dividing "+numbers.get(0)+" by "+numbers.get(1));            
                    int ans=0;
                    while(true)
                    {
                        try 
                        {
                            ans = sc.nextInt();    
                            sc.nextLine();
                            if(calc.FindCorrectResult(ans))
                            {
                                p1.getBucket().AddToy(p1.GetTile().GetToy().clone());
                                System.out.println("You won a " +p1.getBucket().GetToys().get(p1.getBucket().GetToys().size()-1).Getname());
                                break;
                            }
                            else
                            {
                                System.out.println("Wrong answer, No Toy");
                                break;
                            }
                        } 
                        catch (InputMismatchException e) 
                        {
                            sc.nextLine();
                            System.out.println("The type of input is wrong, therefore the answer is wrong");
                            //System.out.println("You did not win a toy. Enter an integer next time instead of String");
                            break;
                        }
                    }

                         
                }
            }           
       }
       System.out.println("Toys you got are");
       for (int i = 0; i < p1.getBucket().GetToys().size(); i++) 
       {
           System.out.println(p1.getBucket().GetToys().get(i).Getname());    
       }
       sc.close();
    }
}


