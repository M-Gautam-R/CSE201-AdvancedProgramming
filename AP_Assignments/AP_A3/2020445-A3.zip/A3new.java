import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
class Dice
{
    private final int numFaces; //maximum face value
    private int faceValue; //current value showing on the dice
    // Constructor: Sets the initial face value.
    public Dice(int _numFaces) {
    numFaces = _numFaces;
    roll();
    }
    // Rolls the dice
    public void roll() 
    {
        setFaceValue();
    }
    // Face value setter/mutator.
    private void setFaceValue () 
    {
        faceValue=ThreadLocalRandom.current().nextInt(1, 2 + 1);
    }

    public int getFaceValue() 
    {
    return faceValue;
    }

    // Face value getter/setter.
    public int getNumFaces() 
    {
    return numFaces;
    }
}

class Player
{
    private String name;
    //private ArrayList<Floor> order= new ArrayList<>();
    private int score;
    private Floor curFloor;
    Player(String n,Floor f)
    {
        name=n;
        curFloor=f;
    }
    Player(String n)
    {
        name=n;
    }

    public void Move(int roll)
    {

    }
    public void SetScore(int num)
    {
        score+=num;
    }
    public void SetFloor(Floor f)
    {
        curFloor=f; 
    }
    public Floor GetFloor()
    {
        return curFloor;
    }
    public int GetScore()
    {
        return score;
    }
    public String getname()
    {
        return name;
    }
}   

abstract class Floor
{
    //private int score; 
    private int floor_no;
    private int nextFloor;
    // Floor(int s, int floor, Floor next)
    // {
    //     score=s;
    //     floor_no=floor;
    //     nextFloor=next;
    // }    
    abstract int GetFloor();
    abstract int getnextFloor();
    abstract int getScore();
}
class EmptyFloor extends Floor
{
    private int score; 
    private int floor_no;
    private int nextfloor;
    EmptyFloor(int s, int floor, int next)
    {
        score=s;
        floor_no=floor;
        nextfloor=next;
    }
    public void IncScore(Player p,int score)
    {
        p.SetScore(score);
    }
    @Override
    public int GetFloor()
    {
        return floor_no;
    }
    @Override
    public int getnextFloor()
    {
        return nextfloor;
    }
    @Override
    public int getScore()
    {
        return score;
    }   
}
abstract class snakeclass extends Floor
{
    abstract void DecScore(Player p);
}
class Snake extends snakeclass
{
    private int score; 
    private int floor_no;
    private int nextFloor;
    Snake( int floor,int nextF)
    {
        floor_no=floor;
        nextFloor=nextF;
    }  
    @Override
    public int GetFloor()
    {
        return floor_no;
    }
    @Override
    public int getnextFloor()
    {
        return nextFloor;
    } 
    @Override
    public int getScore()
    {
        return score;
    }
    @Override
    public void DecScore(Player p)
    {
        p.SetScore(-2);
    }   
}

class KingCobra extends snakeclass
{
    private int score; 
    private int floor_no;
    private int nextFloor;
    KingCobra(int floor,int nextF)
    {
        floor_no=floor;
        nextFloor=nextF;
    }  
    @Override
    public int GetFloor()
    {
        return floor_no;
    }
    @Override
    public int getnextFloor()
    {
        return nextFloor;
    } 
    @Override
    public int getScore()
    {
        return score;
    }
    @Override
    public void DecScore(Player p)
    {
        p.SetScore(-4);
    }   
    
}
abstract class ladderclass extends Floor
{
    abstract void IncScore(Player p);
}
class ladder extends ladderclass
{
    private int score; 
    private int floor_no;
    private int nextFloor;
    ladder( int floor,int nextF)
    {
        floor_no=floor;
        nextFloor = nextF;
    }
    @Override
    public int GetFloor()
    {
        return floor_no;
    }
    @Override
    public int getnextFloor()
    {
        return nextFloor;
    }   
    @Override
    public int getScore()
    {
        return score;
    }
    @Override
    public void IncScore(Player p)
    {
        p.SetScore(2);
    }   
}
class Elevator extends ladderclass
{
    private int score; 
    private int floor_no;
    private int nextFloor;
    Elevator( int floor,int nextF)
    {
        floor_no=floor;
        nextFloor = nextF;
    }
    @Override
    public int GetFloor()
    {
        return floor_no;
    }
    @Override
    public int getnextFloor()
    {
        return nextFloor;
    }   
    @Override
    public int getScore()
    {
        return score;
    }
    @Override
    public void IncScore(Player p)
    {
        p.SetScore(4);
    }   
}

public class A3new 
{
    public static void main(String[] args) 
    {
        EmptyFloor floor0 = new EmptyFloor(1, 0,1);
        // EmptyFloor floor1 = new EmptyFloor(1, 1);
        // ladder floor2 = new ladder(2, 10);
        // EmptyFloor floor3 = new EmptyFloor(3, 1);
        // EmptyFloor floor4 = new EmptyFloor(4, 1);
        // Snake floor5 = new Snake(5, -2);
        // EmptyFloor floor6 = new EmptyFloor(6, 1);
        // EmptyFloor floor7 = new EmptyFloor(7, 1);
        // ladder floor8 = new ladder(8, 2);
        // EmptyFloor floor9 = new EmptyFloor(9,1);
        // EmptyFloor floor10 = new EmptyFloor(10, 1);
        // Snake floor11 = new Snake(11,-4);
        // EmptyFloor floor12 = new EmptyFloor(12, 1);
        // EmptyFloor floor13 = new EmptyFloor(13, 1);

        int diceroll=0;
        int curFloor=0;
        int nextfloor=0;
        boolean start = false;
        Scanner scan = new Scanner(System.in);
        Dice dice = new Dice(2);
        System.out.print("Enter player name and hit enter:");
        String namString= scan.nextLine();
        Player player = new Player(namString);
        System.out.println("The game setup is ready");
        while(start==false)
        {
            System.out.println("hit enter to roll dice");
            String d = scan.nextLine();
            if(d.equals("\n"))
            {
                System.out.println("it works");
            }
            dice.roll();
            diceroll=dice.getFaceValue();
            System.out.println("Dice rolled "+diceroll);
        
            if(diceroll==1)
            {
                curFloor=0;
                player.SetFloor(floor0);
                floor0.IncScore(player,floor0.getScore());
                System.out.println("player position is Floor 1 -"+curFloor);
                System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                start=true;
            }
            else if (diceroll==2)
            {
                System.out.println("Game cannot start until you get 1 ");
            }
        }
        while(player.GetFloor().GetFloor()!=13)
        {
            System.out.print("hit enter to start game");
            String d = scan.nextLine();
            if(d.equals("\n"))
            {
                System.out.println("it works");
            }
            dice.roll();
            diceroll=dice.getFaceValue();
            System.out.println("Dice rolled "+diceroll);
            
            if(start==true)
            {
                if(diceroll==1)
                {
                    curFloor= player.GetFloor().GetFloor();
                    nextfloor = curFloor+1;
                    if(nextfloor ==0||nextfloor==1|| nextfloor==3||nextfloor==4||nextfloor==6||nextfloor==7||nextfloor==9||nextfloor==10||nextfloor==12||nextfloor==13)
                    {
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore());
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println("player position is Floor-"+curFloor);
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                    else if(nextfloor==2)
                    {
                        Elevator lfloor = new Elevator(2,10);
                        lfloor.IncScore(player);
                        System.out.println("player position is Floor-"+nextfloor);
                        System.out.println(player.getname()+" has reached an Elevator Floor and total score is "+ player.GetScore());
                        nextfloor= lfloor.getnextFloor();
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore()); 
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println("player position is Floor-"+curFloor);
                          
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                    else if(nextfloor==8)
                    {
                        ladder lfloor = new ladder(8,12);
                        lfloor.IncScore(player);
                        System.out.println("player position is Floor-"+nextfloor);
                        System.out.println(player.getname()+" has reached a ladder Floor and total score is "+ player.GetScore());
                        nextfloor= lfloor.getnextFloor();
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore());    
                        curFloor=player.GetFloor().GetFloor();
                       
                        System.out.println("player position is Floor-"+curFloor);
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                    else if(nextfloor==5)
                    {
                        Snake sfloor = new Snake(5,1);
                        sfloor.DecScore(player);
                        System.out.println("player position is Floor-"+nextfloor);
                        System.out.println(player.getname()+" has reached a snake Floor and total score is "+ player.GetScore());
                        nextfloor= sfloor.getnextFloor();
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore());    
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println(curFloor +" "+nextfloor);
                        System.out.println("player position is Floor-"+curFloor);
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                    else if(nextfloor==11)
                    {  
                        KingCobra cfloor = new KingCobra(11,3);
                        cfloor.DecScore(player);
                        System.out.println("player position is Floor-"+nextfloor);
                        System.out.println(player.getname()+" has reached a king cobra Floor and total score is "+ player.GetScore());
                        nextfloor= cfloor.getnextFloor();
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore());   
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println(curFloor +" "+nextfloor);
                        System.out.println("player position is Floor-"+curFloor); 
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                }
                else if(diceroll==2)
                {
                    curFloor = player.GetFloor().GetFloor();
                    nextfloor = curFloor+2;
                    if(curFloor==12)
                    {
                        System.out.println("Player cannot move");
                    }
                    else if(nextfloor ==0||nextfloor==1|| nextfloor==3||nextfloor==4||nextfloor==6||nextfloor==7||nextfloor==9||nextfloor==10||nextfloor==12||nextfloor==13)
                    {
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore());
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println("player position is Floor-"+curFloor); 
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                    else if(nextfloor==2)
                    {
                        
                        Elevator lfloor = new Elevator(2,10);
                        lfloor.IncScore(player);
                        System.out.println("player position is Floor-"+nextfloor);
                        System.out.println(player.getname()+" has reached an Elevator Floor and total score is "+ player.GetScore());
                        nextfloor= lfloor.getnextFloor();
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore()); 
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println("player position is Floor-"+curFloor);
                           
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                    else if(nextfloor==8)
                    {
                        
                        ladder lfloor = new ladder(8,12);
                        lfloor.IncScore(player);
                        System.out.println("player position is Floor-"+nextfloor);
                        System.out.println(player.getname()+" has reached a ladder Floor and total score is "+ player.GetScore());
                        nextfloor= lfloor.getnextFloor();
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore());    
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println(curFloor +" "+nextfloor);
                        System.out.println("player position is Floor-"+curFloor);
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                    else if(nextfloor==5)
                    {
                        Snake sfloor = new Snake(5,1);
                        sfloor.DecScore(player);
                        System.out.println("player position is Floor-"+nextfloor);
                        System.out.println(player.getname()+" has reached a snake Floor and total score is "+ player.GetScore());
                        nextfloor= sfloor.getnextFloor();
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore());    
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println(curFloor +" "+nextfloor);
                        System.out.println("player position is Floor-"+curFloor);
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                    else if(nextfloor==11)
                    {
                        System.out.println("player position is Floor-"+nextfloor);
                        KingCobra cfloor = new KingCobra(11,3);
                        cfloor.DecScore(player);
                        System.out.println(player.getname()+" has reached a king cobra Floor and total score is "+ player.GetScore());
                        nextfloor= cfloor.getnextFloor();
                        EmptyFloor efloor= new EmptyFloor(1, nextfloor,nextfloor+1);
                        player.SetFloor(efloor);
                        efloor.IncScore(player,efloor.getScore());   
                        curFloor=player.GetFloor().GetFloor();
                        System.out.println(curFloor +" "+nextfloor);
                        System.out.println("player position is Floor-"+curFloor); 
                        System.out.println(player.getname()+" has reached an Empty Floor and total score is "+ player.GetScore());
                    }
                }
            }
        }
        System.out.println("Game over");
        System.out.println(player.getname() + " accumulated "+player.GetScore() +" Points");
    
    }   
}
