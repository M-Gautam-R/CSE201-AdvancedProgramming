import java.lang.Math;   
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
class Vaccines
{
    private String vac_name;
    private int doses;
    private int dose_gap;

    public Vaccines(String name, int numdoses, int gap)
    {
        this.vac_name=name;
        this.doses=numdoses;
        this.dose_gap=gap;
    }

    public String GetName()
    {
        return vac_name;
    }
    public int GetDoses()
    {
        return doses;
    }
    public int GetGap()
    {
        return dose_gap;
    }

    public String ToString()
    {
        return "Vaccine Name:" +vac_name+" Number of Doses:" +doses + " Gap between Doses:" +dose_gap;
    }
}

class Slot
{
    private int day;
    private Vaccines vac;
    private int quantity;
    public Slot(int DAY,Vaccines vaccine,int num)
    {
        this.day=DAY;
        this.vac=vaccine;
        this.quantity=num;
    }
    public String ToString()
    {
        return "Day: " +this.day+" Available Quantity: " +this.quantity + " Vaccine:" +this.vac.GetName();
    }
    public String GetName()
    {
        return vac.GetName();
    }

    public Vaccines GetVaccine()
    {
        return vac;
    }
    public int Getday()
    {
        return day;
    }
    public int GetQuantity()
    {
        return quantity;
    }
    public void SetQuantity()
    {
        quantity--;
    }

}

class Citizen
{
    private String citizen_name;
    private int age;
    private String uid;
    private Vaccines vaccine;
    private int latestvacdate;
    private int doses=0;
    private int doses_left;
    private int time_nextdose;
    private String status;
    private String[] stat={"Registered","PARTIALLY VACCINATED","FULLY VACCINATED"};

    public Citizen(String name, int AGE, String id)
    {
        citizen_name=name;
        age=AGE;
        uid=id;
        status="REGISTERED";
    }

    public String GetName()
    {
        return citizen_name;
    }
    public int GetAge()
    {
        return age;
    }
    public String GetID()
    {
        return uid;
    }
    public String ToString()
    {
        return "Citizen Name:" +this.citizen_name+" Age:" +this.age + " ID:" +this.uid;
    }
    public void GetVaccinated(Vaccines Vaccine,Slot slot)
    {
        if(doses==0)
        {
            vaccine=Vaccine;
            doses++;
            doses_left=vaccine.GetDoses()-1;
            time_nextdose=vaccine.GetGap();
            status="PARTIALLY VACCINATED";
            latestvacdate=slot.Getday();
            slot.SetQuantity();
        }
        else if(doses>0)
        {
            if(slot.GetVaccine().GetName()==vaccine.GetName())
            {
                if(doses_left>0)
                {
                    if(slot.Getday()>=latestvacdate+time_nextdose)
                    {    
                        doses++;
                        doses_left--;
                        if(doses_left==0)
                        {
                            status="FULLY VACCINATED";
                        }
                        else
                        {
                            status="PARTIALLY VACCINATED";
                            latestvacdate=slot.Getday();
                            time_nextdose=vaccine.GetGap();
                            slot.SetQuantity();    
                        }
                    }        
                }
                else if(doses_left==0)
                {
                    
                }
            }
            else
            {
                System.out.println("Vaccine mixing not allowed");
            }
        }
    }
    public Vaccines GetVaccine()
    {
        return vaccine;
    }

    public String GetStatus()
    {
        return status;
    }

    public int GetDoses() {
        return doses;
    }
    public int GetTimetoNextDose()
    {
        return time_nextdose;
    }
    public int lastVacDate()
    {
        return latestvacdate;
    }
}
class Hospital
{
    private String hospital_name;
    private int pincode;
    private int uid;
    private static int count=1;
    private ArrayList<Slot> slot_list = new ArrayList<Slot>();    
    public Hospital(String name, int pin)
    {
        System.out.println(count);
        
        hospital_name=name;
        pincode=pin;
        uid=ThreadLocalRandom.current().nextInt(100001, 999999 + 1);
        //uid=count;
        count=count+1;
    }

    public String GetName()
    {
        return hospital_name;
    }
    public int GetPin()
    {
        return pincode;
    }
    public int GetID()
    {
        return uid;
    }
    public ArrayList<Slot> GetSlots()
    {
        return slot_list;
    }
    public void AddSlot(Slot slot)
    {
        slot_list.add(slot);
    }

    public String ToString()
    {
        return " Hospital Name:" +this.hospital_name+" Pincode:" +this.pincode + " ID:" +this.uid;
    }
}

public class A1
{
    public static void main(String[] args) 
    {
        ArrayList<Vaccines> vac_list = new ArrayList<Vaccines>();
        ArrayList<Citizen> citizen_list = new ArrayList<Citizen>();
        ArrayList<Hospital> hospital_list = new ArrayList<Hospital>();
        Scanner sc = new Scanner(System.in);
        int choice =0;

        while(true)
        {
            System.out.println("------------------------");
            System.out.println("1.Add Vaccine");
            System.out.println("2.Register Hospital");
            System.out.println("3.Register Citizen");
            System.out.println("4.Create Slots");
            System.out.println("5.Book a slot");
            System.out.println("6.Slots available with a hospital");
            System.out.println("7.Check Vaccination Status");
            System.out.println("8.Exit");
            System.out.println("------------------------");
          
            choice=sc.nextInt();
            if(choice==1)
            {
                System.out.print("Vaccine name:");
                sc.nextLine();
                String name = sc.nextLine();
                System.out.print("Number of Doses:");
                int num_doses=sc.nextInt();
                System.out.print("Gap between doses:");
                int num_gap=sc.nextInt();
                Vaccines new_vac = new Vaccines(name,num_doses,num_gap);
                int exist_flag=0;
                for (Vaccines vaccines : vac_list) 
                {
                    if(vaccines.GetName().equals(new_vac.GetName()))
                    {
                        exist_flag=1;
                        break;
                    }    
                }
                if(exist_flag==0)
                {
                    System.out.println(new_vac.ToString());
                    vac_list.add(new_vac);    
                }
                else
                {
                    System.out.println("Duplicate Vaccine not allowed");
                }
            }
            else if(choice==2)
            {
                System.out.print("Hospital name:");
                sc.nextLine();
                String name = sc.nextLine();
                System.out.print("Pincode:");
                int num_doses=sc.nextInt();
                Hospital new_hospital = new Hospital(name,num_doses);
                System.out.println(new_hospital.ToString());
                hospital_list.add(new_hospital);
            }
            else if(choice==3)
            {
                System.out.print("Citizen name:");
                sc.nextLine();
                String name = sc.nextLine();
                System.out.print("Age:");
                int age=sc.nextInt();
                System.out.print("UID:");
                String id=sc.next();
                Citizen new_Citizen = new Citizen(name,age,id);
                if(Long.valueOf(age)>=18)
                {
                    int exist_flag=0;
                    for (Citizen citizen : citizen_list) 
                    {
                        if(citizen.GetName().equals(new_Citizen.GetName()))
                        {
                            exist_flag=1;
                            break;
                        }    
                    }
                    if(exist_flag==0)
                    {
                        System.out.println(new_Citizen.ToString());   
                        citizen_list.add(new_Citizen);  
                    }
                    else
                    {
                        System.out.println("Duplicate Citizen not allowed");
                    }
                }
                else if(Long.valueOf(age)<18)
                {
                    System.out.println("Only above 18 are allowed");    
                }
                                 
            }
            else if(choice==4)
            {
                System.out.print("Hospital ID:");
                int hospitalID = sc.nextInt();
                System.out.print("Enter no of slots to be added:");
                int numslots = sc.nextInt();
                for(int i=0;i<numslots;i++)
                {
                    System.out.print("Enter day number:");
                    int day = sc.nextInt();
                    System.out.print("Quantity:");
                    int num_doses=sc.nextInt();
                    System.out.println("Select Vaccine");
                    for(int j=0;j<vac_list.size();j++)
                    {
                        System.out.println(j+". "+vac_list.get(j).GetName());
                    }
                    int vac_choice;
                    vac_choice=sc.nextInt();

                    Slot slot = new Slot(day, vac_list.get(vac_choice), num_doses);

                    for (Hospital hospital : hospital_list) 
                    {
                        if(hospital.GetID()==hospitalID)
                        {
                            hospital.AddSlot(slot);
                            System.out.println("Slot added by Hospital "+hospitalID +"for "+slot.ToString());
                            break;
                        }    
                    }
                }
            }
            else if(choice==5)
            {
                System.out.println("Enter Patient ID:");
                String citizenID=sc.next();
                System.out.println("1.Search By Area");
                System.out.println("2.Search By Vaccine");
                int search_choice=sc.nextInt();

                if(search_choice==1)
                {
                    ArrayList<Slot> slots=new ArrayList<Slot>();
                    System.out.println("Enter pincode:");
                    int pin=sc.nextInt();
                    for (Hospital hospital : hospital_list) 
                    {
                        if(hospital.GetPin()==pin)
                        {
                            System.out.println(hospital.GetPin()+" "+hospital.GetName());
                        }    
                    }
                    int idHospital;
                    System.out.println("Enter hospital ID:");
                    idHospital=sc.nextInt();
                    int flag=0;
                    int slot_flag=0;
                    for (int j=0;j<hospital_list.size();j++) 
                    {
                        if(hospital_list.get(j).GetID()==idHospital)
                        {
                            ArrayList<Slot> Hslots = hospital_list.get(j).GetSlots();
                            for (int k = 0; k <Hslots.size(); k++) 
                            {
                                for (Citizen citizen : citizen_list) 
                                {
                                    if(citizen.GetID().equals(citizenID))
                                    {
                                        if(citizen.GetDoses()==0)
                                        {
                                            slot_flag=1;
                                            slots.add(Hslots.get(k));
                                            System.out.println(k+"-> "+Hslots.get(k).ToString());                              
                                    
                                        }
                                        else if(citizen.GetTimetoNextDose()>=Hslots.get(k).Getday());
                                        {
                                            slot_flag=1;
                                            slots.add(Hslots.get(k));
                                            System.out.println(k+"-> "+Hslots.get(k).ToString());                              
                                        }
                                    }    
                                }
                            }
                        }
                    }
                    
                    int vac_choice;                    // The actual booking part
                    if(slot_flag==0)
                    {
                        System.out.println("No slots available");
                    }
                    else
                    {
                        System.out.println("Choose slot");
                        vac_choice=sc.nextInt();

                        for (Citizen citizen : citizen_list) 
                        {
                            //System.out.println("inside for works");
                            //System.out.println(citizenID+" "+citizen.GetID());
                            if(citizen.GetID().equals(citizenID))
                            {
                                //System.out.println("inside if Worked");
                                citizen.GetVaccinated(slots.get(vac_choice).GetVaccine(),slots.get(vac_choice));
                                System.out.println(citizen.GetName()+"vaccinated with "+citizen.GetVaccine().GetName());  
                            }    
                        }
                    }

                }
                else if(search_choice==2)
                {
                    ArrayList<Slot> slots=new ArrayList<Slot>();
                    System.out.println("Enter Vaccine name:");
                    sc.nextLine();
                    String vacName=sc.nextLine();
                    for (Hospital hospital : hospital_list) 
                    {
                        ArrayList<Slot> Hslots = hospital.GetSlots();
                        for (Slot slot : Hslots) 
                        {
                            if(slot.GetName().equals(vacName))
                            {
                                System.out.println(hospital.GetID()+" "+hospital.GetName());
                            }    
                        }
                    }
                    int idHospital;
                    System.out.println("Enter hospital ID:");
                    idHospital=sc.nextInt();
                    //int flag=0;
                    int slot_flag=0;
                    for (int j=0;j<hospital_list.size();j++) 
                    {
                        if(hospital_list.get(j).GetID()==idHospital)
                        {
                            //flag=1;
                            ArrayList<Slot> Hslots = hospital_list.get(j).GetSlots();
                            for (int k = 0; k <Hslots.size(); k++) 
                            {
                                for (Citizen citizen : citizen_list) 
                                {
                                    if(citizen.GetID().equals(citizenID))
                                    {
                                        int val=citizen.GetTimetoNextDose()+citizen.lastVacDate();
                                        //System.out.println(Hslots.get(k).Getday()+" "+val);
                                        if(Hslots.get(k).Getday()>=val)
                                        {
                                            slot_flag=1;
                                            slots.add(Hslots.get(k));
                                            System.out.println(k+"-> "+Hslots.get(k).ToString());                              
                                        }
                                    }    
                                }
                            }
                        }

                    }
                    int vac_choice;                    // The actual booking part
                    if(slot_flag==0)
                    {
                        System.out.println("No slots available");
                    }
                    else
                    {
                        System.out.println("Choose slot");
                        vac_choice=sc.nextInt();
                        for (Citizen citizen : citizen_list) 
                        {
                            if(citizen.GetID().equals(citizenID))
                            {
                                citizen.GetVaccinated(slots.get(vac_choice).GetVaccine(),slots.get(vac_choice));
                                System.out.println(citizen.GetName()+"vaccinated with "+citizen.GetVaccine().GetName());
                            }    
                        }
                    }    
                }
            }
            else if(choice==6)
            {
                System.out.print("Enter Hospital ID:");
                int hospitalID=sc.nextInt();
                Hospital hospital=null;
                for (Hospital HOPITAL : hospital_list) 
                {
                    if(HOPITAL.GetID()==hospitalID)
                    {
                        hospital=HOPITAL;
                        break;
                    }
                }
                for (Slot slot : hospital.GetSlots()) 
                {
                    System.out.println(slot.ToString());        
                }
            }
            else if(choice==7)
            {
                System.out.println("Enter Patient ID:");
                String citizenid=sc.next();
                for (Citizen citizen : citizen_list) 
                {
                    if(citizen.GetID().equals(citizenid))
                    {
                        String status = citizen.GetStatus();
                        if(status=="REGISTERED")
                        {
                            System.out.println("Citizen REGISTERED");
                        }
                        else if(status=="PARTIALLY VACCINATED")
                        {
                            int value=citizen.GetTimetoNextDose()+citizen.lastVacDate();
                            System.out.println("PARTIALLY VACCINATED");
                            System.out.println("Vaccine given "+citizen.GetVaccine().GetName());
                            System.out.println("No of doses given "+citizen.GetDoses());
                            System.out.println("Next Due date "+value);                            
                        }
                        else if(status=="FULLY VACCINATED")
                        {
                            System.out.println("FULLY VACCINATED");
                            System.out.println("Vaccine given "+citizen.GetVaccine().GetName());
                            System.out.println("No of doses given "+citizen.GetDoses());                            
                        }
                        
                    }    
                }
            }
            else if(choice==8)
            {
                break;
            }
        }
    }
}
